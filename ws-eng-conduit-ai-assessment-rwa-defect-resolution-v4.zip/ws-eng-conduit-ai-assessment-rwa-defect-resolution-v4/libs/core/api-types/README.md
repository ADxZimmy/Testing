# core-api-types

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test core-api-types` to execute the unit tests.
