# profile-feature-profile

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test profile-feature-profile` to execute the unit tests.
