export * from './lib/pager/pager.component';
