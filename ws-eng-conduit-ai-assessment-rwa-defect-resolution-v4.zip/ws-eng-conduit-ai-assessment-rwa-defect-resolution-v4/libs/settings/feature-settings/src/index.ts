export * from './lib/settings.component';
